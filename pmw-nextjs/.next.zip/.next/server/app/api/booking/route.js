var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/booking/route.js")
R.c("server/chunks/[root-of-the-server]__0iacnob._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_booking_route_actions_0~hjigu.js")
R.m(52127)
module.exports=R.m(52127).exports
