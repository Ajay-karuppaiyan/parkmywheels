module.exports=[33924,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_parking-business_page_actions_10_1wp~.js.map