module.exports=[97714,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_corporate-parking_page_actions_05hs.yo.js.map