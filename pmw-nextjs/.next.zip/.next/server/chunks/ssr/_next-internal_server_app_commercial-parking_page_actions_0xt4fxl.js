module.exports=[85759,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_commercial-parking_page_actions_0xt4fxl.js.map