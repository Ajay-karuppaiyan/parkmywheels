globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/sCR0QsXL3oKc86VQvLDus/_buildManifest.js",
    "static/sCR0QsXL3oKc86VQvLDus/_ssgManifest.js",
    "static/sCR0QsXL3oKc86VQvLDus/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0-4oo_oi06i0r.js",
    "static/chunks/15xjc7n-ri.fu.js",
    "static/chunks/0wj8l4fwydekq.js",
    "static/chunks/0qtz4meecy2cb.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/turbopack-05pl9z1s_hvb1.js"
  ]
};
